// ********************************************************************************
// DisplayPort Sink/Source System Library data types
//
// All rights reserved. Property of Bitec.
// Restricted rights to use, duplicate or disclose this code are
// granted through contract.
//
// (C) Copyright Bitec 2012
//    All rights reserved
//
// Author         : $Author: psgswbuild $ @ bitec-dsp.com
// Department     :
// Date           : $Date: 2020/04/03 $
// Revision       : $Revision: #1 $
// URL            : $URL: svn://10.9.0.1/dp/trunk/software/btc_dprx_syslib/btc_dp_types.h $
//
// Description:
//
// ********************************************************************************

#ifndef _BTC_DP_TYPES_INCLUDE
#define _BTC_DP_TYPES_INCLUDE

#define BYTE  unsigned char
#define NIL   0xffffffff

#endif //#ifndef _BTC_DP_TYPES_INCLUDE
