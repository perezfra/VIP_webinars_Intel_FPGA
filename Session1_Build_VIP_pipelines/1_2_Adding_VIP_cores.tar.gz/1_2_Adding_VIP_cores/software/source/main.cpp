// ********************************************************************************
// DisplayPort Core test code main
//
// All rights reserved. Property of Bitec.
// Restricted rights to use, duplicate or disclose this code are
// granted through contract.
//
// (C) Copyright Bitec 2012
//    All rights reserved
//
// Author         : $Author: psgswbuild $ @ bitec-dsp.com
// Department     :
// Date           : $Date: 2020/04/03 $
// Revision       : $Revision: #1 $
// URL            : $URL: svn://nas-bitec-fi/dp/trunk/software/dp_demo/main.c $
//
// Description:
//
// ********************************************************************************

#include <stdio.h>
#include <unistd.h>
#include <io.h>
#include <fcntl.h>
#include <string.h>
#include "sys/alt_timestamp.h"
#include "alt_types.h"
#include "sys/alt_irq.h"
#include "debug.h"
#include "intel_fpga_i2c.h"
#include "config.h"
#include "tx_utils.h"
#include "rx_utils.h"

#if DP_SUPPORT_TX_HDCP
#include "hdcp.h"
#endif


// -------------------------------------------------------------------------------------------------------------------
// VIP added stuff
// -------------------------------------------------------------------------------------------------------------------
#include "Clocked_Video_Output.hpp"
#include "Test_Pattern_Generator.hpp"


#if PSG_8K_EDID
// Intel PSG 8K30 EDID
BYTE intel_psg_edid[256] =
{
   0x00,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x00,
   0x42,0x67,0x00,0x00,0x00,0x00,0x00,0x00,
   0x2E,0x1C,0x01,0x04,0xA5,0x46,0x27,0x78,
   0x3A,0x77,0x45,0xAE,0x51,0x33,0xBA,0x26,
   0x0D,0x50,0x54,0xA5,0x4B,0x00,0x81,0x00,
   0xB3,0x00,0xD1,0x00,0xA9,0x40,0x81,0x80,
   0xD1,0xC0,0x01,0x00,0x01,0x00,0x4D,0xD0,
   0x00,0xA0,0xF0,0x70,0x3E,0x80,0x30,0x20,
   0x35,0x00,0xBA,0x89,0x21,0x00,0x00,0x1A,
   0x00,0x00,0x00,0x10,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x10,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFC,
   0x00,0x50,0x53,0x47,0x2D,0x38,0x4B,0x33,
   0x30,0x0A,0x20,0x20,0x20,0x20,0x01,0xD7,
   0x70,0x12,0x1E,0x00,0x00,0x81,0x00,0x04,
   0x23,0x08,0x1F,0x03,0x03,0x00,0x14,0x65,
   0x8E,0x01,0x84,0xFF,0x1D,0x4F,0x00,0x07,
   0x80,0x1F,0x00,0xDF,0x10,0x3C,0x00,0x2E,
   0x00,0x07,0x00,0xFE,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x90
};
#else
  #if BITEC_RX_CAPAB_MST && BITEC_TX_CAPAB_MST
  // MST is enabled 
  BYTE intel_psg_edid[128] =
  {
  0x00,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x00,
  0x10,0xAC,0x8B,0x40,0x4C,0x35,0x33,0x30,
  0x2A,0x17,0x01,0x04,0xA5,0x43,0x1C,0x78,
  0x3E,0xEE,0x95,0xA3,0x54,0x4C,0x99,0x26,
  0x0F,0x50,0x54,0xA5,0x4B,0x00,0x81,0x00,
  0xB3,0x00,0x71,0x4F,0x81,0x80,0xD1,0xC0,
  0x01,0x01,0x01,0x01,0x01,0x01,0x7E,0x48,
  0x80,0xE0,0x70,0x38,0x1F,0x40,0x40,0x40,
  0x3A,0x00,0xA1,0x1C,0x21,0x00,0x00,0x1A,
  0x00,0x00,0x00,0xFF,0x00,0x35,0x59,0x44,
  0x38,0x43,0x33,0x41,0x48,0x30,0x33,0x35,
  0x4C,0x0A,0x00,0x00,0x00,0xFC,0x00,0x44,
  0x45,0x4C,0x4C,0x20,0x55,0x32,0x39,0x31,
  0x33,0x57,0x4D,0x0A,0x00,0x00,0x00,0xFD,
  0x00,0x31,0x56,0x1D,0x5E,0x13,0x01,0x0A,
  0x20,0x20,0x20,0x20,0x20,0x20,0x00,0x26
  };
  #else
  //Intel PSG 4K60 EDID
  BYTE intel_psg_edid[128] =
  {
   0x00,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x00,
   0x42,0x67,0x00,0x00,0x00,0x00,0x00,0x00,
   0x2E,0x1C,0x01,0x04,0xA5,0x46,0x27,0x78,
   0x3A,0x77,0x45,0xAE,0x51,0x33,0xBA,0x26,
   0x0D,0x50,0x54,0xA5,0x4B,0x00,0x81,0x00,
   0xB3,0x00,0xD1,0x00,0xA9,0x40,0x81,0x80,
   0xD1,0xC0,0x01,0x00,0x01,0x00,0x4D,0xD0,
   0x00,0xA0,0xF0,0x70,0x3E,0x80,0x30,0x20,
   0x35,0x00,0xBA,0x89,0x21,0x00,0x00,0x1A,
   0x00,0x00,0x00,0x10,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x10,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFC,
   0x00,0x50,0x53,0x47,0x2D,0x34,0x4B,0x36,
   0x30,0x0A,0x20,0x20,0x20,0x20,0x00,0xD9
  };
  #endif
#endif  

void bitec_menu_print();
void bitec_menu_cmd();
void bitec_dprx_init();
void bitec_mc_monitor(void);

extern int new_rx;
extern BYTE tx_edid_data[512]; // TX copy of Sink EDID

int main()
{
  // Force non-blocking jtag uart
  int res = 0;
  res = fcntl(STDOUT_FILENO, F_SETFL, O_NONBLOCK);
  res = fcntl(STDIN_FILENO, F_SETFL, O_NONBLOCK);
  if (res == -1) {
     printf("FCNTL Failed\n");
  }
  printf("Started...\n");
  printf("Running my demo...\n");


  // -------------------------------------------------------------------------------------------------------------------
  // VIP added stuff
  // Create objects for VIP pipeline
  // -------------------------------------------------------------------------------------------------------------------

  Clocked_Video_Output cvo(VIP_PIPELINE_CVO_BASE);
  Test_Pattern_Generator tpg(VIP_PIPELINE_TPG_0_BASE);

  // -------------------------------------------------------------------------------------------------------------------
  // VIP added stuff
  // Initialize objects and start execution
  // -------------------------------------------------------------------------------------------------------------------

  cvo.set_output_mode(0, CVO_1080P_MODE);
  cvo.start();

  tpg.set_width(1920);
  tpg.set_height(1080);
  tpg.set_uniform_color(255, 0, 255);
  tpg.select_pattern(0);	// according to setup in HW
  	  	  	  	  	  	  	// pattern 0 - Color Bars
  	  	  	  	  	  	  	// pattern 1 - Gray Bars
  	  	  	  	  	  	  	// pattern 2 - Uniform Background
  tpg.start();

  // -------------------------------------------------------------------------------------------------------------------

  // Init Bitec DP system library
#if DP_SUPPORT_TX
#if DP_SUPPORT_TX_HDCP
  btc_dptx_syslib_add_tx(0,
                         DP_TX_DP_SOURCE_TX_MGMT_BASE,
                         DP_TX_DP_SOURCE_TX_MGMT_IRQ_INTERRUPT_CONTROLLER_ID,
                         DP_TX_DP_SOURCE_TX_MGMT_IRQ);
  btc_dptx_syslib_init();
#else
  btc_dptx_syslib_add_tx(0,
                         DP_TX_DP_SOURCE_BASE,
                         DP_TX_DP_SOURCE_IRQ_INTERRUPT_CONTROLLER_ID,
                         DP_TX_DP_SOURCE_IRQ);
  btc_dptx_syslib_init();
#endif
#endif
#if DP_SUPPORT_RX
#if BITEC_RX_GPUMODE
#if DP_SUPPORT_RX_HDCP
  btc_dprx_syslib_add_rx(0,
                         DP_RX_DP_SINK_RX_MGMT_BASE,
                         DP_RX_DP_SINK_RX_MGMT_IRQ_INTERRUPT_CONTROLLER_ID,
                         DP_RX_DP_SINK_RX_MGMT_IRQ,
                         DP_RX_DP_SINK_RX_MGMT_BITEC_CFG_RX_MAX_NUM_OF_STREAMS,
                         0);
  btc_dprx_syslib_init();
#else
  btc_dprx_syslib_add_rx(0,
                         DP_RX_DP_SINK_BASE,
                         DP_RX_DP_SINK_IRQ_INTERRUPT_CONTROLLER_ID,
                         DP_RX_DP_SINK_IRQ,
                         DP_RX_DP_SINK_BITEC_CFG_RX_MAX_NUM_OF_STREAMS,
                         0);
  btc_dprx_syslib_init();
#endif
#endif
#endif

#if (BITEC_DP_CARD_REV == 2)
  // Bitec Daughter Card Rev 11
  unsigned int data;
 
  // Init the MCDP6000 on the Bitec Sink main link input
  // (on the Bitec daughter board)
  // Set the MCDP6000 as required by your design
  
  intel_fpga_i2c_init(I2C_MASTER_BASE, 100000000);  

  data = 0x0001704E; intel_fpga_i2c_mc_write(I2C_MASTER_BASE, 0x28 >> 1, 0x0504, (unsigned char *)&data, 4);
  data = 0x00000601; intel_fpga_i2c_mc_write(I2C_MASTER_BASE, 0x28 >> 1, 0x01D8, (unsigned char *)&data, 4);
  data = 0x00005011; intel_fpga_i2c_mc_write(I2C_MASTER_BASE, 0x28 >> 1, 0x0660, (unsigned char *)&data, 4);
  data = 0x00000001; intel_fpga_i2c_mc_write(I2C_MASTER_BASE, 0x28 >> 1, 0x067C, (unsigned char *)&data, 4);
  data = 0x55801E14; intel_fpga_i2c_mc_write(I2C_MASTER_BASE, 0x28 >> 1, 0x0A00, (unsigned char *)&data, 4); // MC solution #2
  data = 0x0000001F; intel_fpga_i2c_mc_write(I2C_MASTER_BASE, 0x28 >> 1, 0x0350, (unsigned char *)&data, 4); // MC solution #3
 
#endif

// Init sink and source

#if DP_SUPPORT_EDID_PASSTHRU
  bitec_dptx_init();
  // Added 100ms delay //
  {
    unsigned int tout;
    alt_timestamp_start();
    tout = alt_timestamp_freq()/10;
    while(alt_timestamp() < tout);
  }
  {
    unsigned int sr;
    sr = IORD(btc_dptx_baseaddr(0),DPTX_REG_TX_STATUS); // Reading SR clears IRQ

    if(sr & 0x04)
    {
      btc_dptx_edid_read(0,tx_edid_data); // Read the sink EDID
      btc_dprx_edid_set(0,0,tx_edid_data,tx_edid_data[126]+1); // EDID Passthru from Sink to Source
    }
    else
    {
      btc_dprx_edid_set(0,0,intel_psg_edid,sizeof(intel_psg_edid)/128);
    }
  }
#else
  bitec_dptx_init();
  if ( BITEC_RX_CAPAB_MST && BITEC_TX_CAPAB_MST )
  {
          // at least 2 streams for MST
          btc_dprx_edid_set(0,0,intel_psg_edid,sizeof(intel_psg_edid)/128); // strm0
          btc_dprx_edid_set(0,1,intel_psg_edid,sizeof(intel_psg_edid)/128); // strm1
          
          if ( MST_RX_STREAMS > 2 )
              btc_dprx_edid_set(0,2,intel_psg_edid,sizeof(intel_psg_edid)/128);  // strm2
          if ( MST_RX_STREAMS > 3 )
              btc_dprx_edid_set(0,3,intel_psg_edid,sizeof(intel_psg_edid)/128);  // strm3
  }
  else
  {     
      btc_dprx_edid_set(0,0,intel_psg_edid,sizeof(intel_psg_edid)/128);
  }
#endif


#if DP_SUPPORT_RX && BITEC_RX_GPUMODE
  btc_dprx_hpd_set(0,0); // HPD = 0

  bitec_dprx_init();

  BTC_DPRX_ENABLE_IRQ(0); // Enable IRQ on AUX Requests from the source

  // Wait for 500 ms to have a long HPD
  {
    unsigned int tout;
    alt_timestamp_start();
    tout = alt_timestamp_freq()/2;
    while(alt_timestamp() < tout);
  }
  btc_dprx_hpd_set(0,1); // HPD = 1
#endif

#if BITEC_AUX_DEBUG
#if DP_SUPPORT_RX
  bitec_dp_dump_aux_debug_init(DP_RX_AUX_RX_DEBUG_FIFO_IN_CSR_BASE);
#endif
#if DP_SUPPORT_TX
  bitec_dp_dump_aux_debug_init(DP_TX_AUX_TX_DEBUG_FIFO_IN_CSR_BASE);
#endif
#endif

#if DP_SUPPORT_TX
  // Check if a Sink is readily connected
  {
    unsigned int sr;
    sr = IORD(btc_dptx_baseaddr(0),DPTX_REG_TX_STATUS); // Reading SR clears IRQ

    if(sr & 0x04)
    {
#if BITEC_TX_CAPAB_MST
      btc_dptxll_hpd_change(0,1);
      pc_fsm = PC_FSM_START;
#else
      btc_dptx_hpd_change(0,1);
      bitec_dptx_linktrain();
#endif
    }
  }

  BTC_DPTX_ENABLE_HPD_IRQ(0); // Enable IRQ on HPD changes from the sink
#endif

  // Main loop
  while(1)
  {
#ifdef ALT_VIP_MIX_0_BASE
    if(IORD(btc_dprx_baseaddr(0), DPRX0_REG_VBID) & 0x80)
      IOWR(ALT_VIP_MIX_0_BASE, 4, 1); // MSA lock -> Enable DP image
    else
      IOWR(ALT_VIP_MIX_0_BASE, 4, 0); // MSA not locked -> Disable DP image

    if(IORD(btc_dprx_baseaddr(0), DPRX1_REG_VBID) & 0x80)
      IOWR(ALT_VIP_MIX_0_BASE, 7, 1); // MSA lock -> Enable DP image
    else
      IOWR(ALT_VIP_MIX_0_BASE, 7, 0); // MSA not locked -> Disable DP image

    if(IORD(btc_dprx_baseaddr(0), DPRX2_REG_VBID) & 0x80)
      IOWR(ALT_VIP_MIX_0_BASE, 10, 1); // MSA lock -> Enable DP image
    else
      IOWR(ALT_VIP_MIX_0_BASE, 10, 0); // MSA not locked -> Disable DP image

    if(IORD(btc_dprx_baseaddr(0), DPRX3_REG_VBID) & 0x80)
      IOWR(ALT_VIP_MIX_0_BASE, 13, 1); // MSA lock -> Enable DP image
    else
      IOWR(ALT_VIP_MIX_0_BASE, 13, 0); // MSA not locked -> Disable DP image
#endif

    // Serve Syslib periodic tasks
#if DP_SUPPORT_TX
    btc_dptx_syslib_monitor();
#if BITEC_TX_CAPAB_MST
    btc_dptxll_syslib_monitor();
#endif
#endif

#if DP_SUPPORT_RX && BITEC_RX_GPUMODE
    btc_dprx_syslib_monitor();
#if (BITEC_DP_CARD_REV == 2)
    bitec_mc_monitor();
#endif
#endif


#if DP_SUPPORT_TX && BITEC_TX_CAPAB_MST
    // Simulate the user MST TX application
    bitec_dptx_pc();
#endif

#if BITEC_AUX_DEBUG
    // Dump AUX channel traffic
#if DP_SUPPORT_RX
    bitec_dp_dump_aux_debug(DP_RX_AUX_RX_DEBUG_FIFO_IN_CSR_BASE, DP_RX_AUX_RX_DEBUG_FIFO_OUT_BASE, 1);
#endif
#if DP_SUPPORT_TX
    bitec_dp_dump_aux_debug(DP_TX_AUX_TX_DEBUG_FIFO_IN_CSR_BASE, DP_TX_AUX_TX_DEBUG_FIFO_OUT_BASE, 0);
#endif
#endif

    // Serve menu commands, if any
    bitec_menu_cmd();

#if DP_SUPPORT_TX_HDCP
    hdcp_main();
#endif

#if DP_SUPPORT_EDID_PASSTHRU
	// If new Sink detected, pass-thru the EDID from Sink to Source    
    if(new_rx)
    {
        new_rx = 0;
 
        btc_dprx_hpd_set(0,0); // HPD = 0

        // Init the EDID(s)
      btc_dptx_edid_read(0,tx_edid_data); // Read the sink EDID
        btc_dprx_edid_set(0,0,tx_edid_data,tx_edid_data[126]+1);

      // Wait for 500 ms to have a long HPD
      {
         unsigned int tout;
         alt_timestamp_start();
         tout = alt_timestamp_freq()/2;
         while(alt_timestamp() < tout);
      }
      btc_dprx_hpd_set(0,1); // HPD = 1
        
    }

    // Detect RX Colormetry and update TX MSA accordingly
    unsigned int rx_color_enc, rx_color_range, rx_color_colorimetry, rx_color_bpc, rx_color_sdp; 
    unsigned int rx_color, tx_color;
	rx_color = IORD(btc_dprx_baseaddr(0), DPRX0_REG_MSA_COLOUR) & 0xFFFF;
	rx_color_enc = (IORD(btc_dprx_baseaddr(0), DPRX0_REG_MSA_COLOUR) >> 4) & 0x0f;
	rx_color_range = (IORD(btc_dprx_baseaddr(0), DPRX0_REG_MSA_COLOUR) >> 12) & 0x01;
	rx_color_colorimetry = (IORD(btc_dprx_baseaddr(0), DPRX0_REG_MSA_COLOUR) >> 8) & 0x0f;
	rx_color_bpc = (IORD(btc_dprx_baseaddr(0), DPRX0_REG_MSA_COLOUR) >> 0) & 0x07;
	rx_color_sdp = (IORD(btc_dprx_baseaddr(0), DPRX0_REG_MSA_COLOUR) >> 13) & 0x01;
	tx_color = IORD(btc_dptx_baseaddr(0), DPTX0_REG_MSA_COLOUR) & 0xFFFF;
	if(rx_color != tx_color)
	{
		btc_dptx_video_enable(0,0);
		btc_dptx_set_color_space(0,rx_color_enc,rx_color_bpc,rx_color_range,rx_color_colorimetry,rx_color_sdp);
		btc_dptx_video_enable(0,1);
	}
	
#endif

#if DP_SUPPORT_RX
    if(IORD(DP_RX_PIO_0_BASE,0))
    {
      // User pushbutton pressed
#if 0
#if BITEC_RX_GPUMODE
      btc_dprx_hpd_set(0,0); // HPD = 0

      // Wait for 500 ms to have a long HPD
      {
        unsigned int tout;
        alt_timestamp_start();
        tout = alt_timestamp_freq()/2;
        while(alt_timestamp() < tout);
      }
      btc_dprx_hpd_set(0,1); // HPD = 1
#endif
#else

      // Wait for 500 ms to avoid bouncing
      {
        unsigned int tout;
        alt_timestamp_start();
        tout = alt_timestamp_freq()/2;
        while(alt_timestamp() < tout);
      }

  #if BITEC_STATUS_DEBUG
      // Dump MSA
    #if DP_SUPPORT_TX
      bitec_dp_dump_source_msa(btc_dptx_baseaddr(0));
      bitec_dp_dump_source_config(btc_dptx_baseaddr(0));
         
      if ( BITEC_RX_CAPAB_MST && BITEC_TX_CAPAB_MST )
      {
          // strm 1
          bitec_dp_dump_source_msa(btc_dptx_baseaddr(1));
          bitec_dp_dump_source_config(btc_dptx_baseaddr(1));
          
          if ( MST_RX_STREAMS > 2 ) 
          {
              // strm 2
              bitec_dp_dump_source_msa(btc_dptx_baseaddr(2));
              bitec_dp_dump_source_config(btc_dptx_baseaddr(2));
          }
          if ( MST_RX_STREAMS > 3 )
          {
              // strm 3
              bitec_dp_dump_source_msa(btc_dptx_baseaddr(3));
              bitec_dp_dump_source_config(btc_dptx_baseaddr(3));
          }
      }
      
    #endif
      bitec_dp_dump_sink_msa(btc_dprx_baseaddr(0));
      bitec_dp_dump_sink_config(btc_dprx_baseaddr(0));
      
      if ( BITEC_RX_CAPAB_MST && BITEC_TX_CAPAB_MST )
      {
          // strm 1
          bitec_dp_dump_sink_msa(btc_dprx_baseaddr(1));
          bitec_dp_dump_sink_config(btc_dprx_baseaddr(1));
          
          if ( MST_RX_STREAMS > 2 ) 
          {
              // strm 2
              bitec_dp_dump_sink_msa(btc_dprx_baseaddr(2));
              bitec_dp_dump_sink_config(btc_dprx_baseaddr(2));
          }
          if ( MST_RX_STREAMS > 3 )
          {
              // strm 3
              bitec_dp_dump_sink_msa(btc_dprx_baseaddr(3));
              bitec_dp_dump_sink_config(btc_dprx_baseaddr(3));
          }
      }
  #endif

#endif
    }
#endif
  }

  return 0; // Should never get here
}

// Printout all menu commands
void bitec_menu_print()
{
#if BITEC_STATUS_DEBUG
	printf("h = Help\n");
	printf("s = Status\n");
	printf("c = Read Sink DPCD CRC\n");
	printf("v = Print versions\n");
#if BITEC_DP_0_AV_TX_CONTROL_BITEC_CFG_TX_SUPPORT_HDCP1
	printf("ha1 = HDCP 1.3 TX authenticate\n");
#endif
#if BITEC_DP_0_AV_TX_CONTROL_BITEC_CFG_TX_SUPPORT_HDCP2
  printf("ha2 = HDCP 2.2 TX authenticate\n");
#endif
#if BITEC_DP_0_AV_TX_CONTROL_BITEC_CFG_TX_SUPPORT_HDCP1 || BITEC_DP_0_AV_TX_CONTROL_BITEC_CFG_TX_SUPPORT_HDCP2
	printf("h0 = HDCP TX encryption off\n");
	printf("h1 = HDCP TX encryption on\n");
#endif
#endif
}

// Implementation of menu commands
void bitec_menu_cmd()
{
#if BITEC_STATUS_DEBUG
	char *cmd;

	cmd = bitec_get_stdin();
    if(cmd != NULL)
    {
        if(cmd[0] == 'c')
        {
          BYTE d[6];
          // Sink CRC
          d[0]=1;
          btc_dptx_aux_write(0,DPCD_ADDR_TEST_SINK,1,d);
          usleep(50000);
          btc_dptx_aux_read(0,DPCD_ADDR_TEST_CRC_R_CR_LSB,6,d);
          printf("CRC R : %4.4x  CRC G : %4.4x  CRC B : %4.4x\n", d[0]+(d[1]<<8),d[2]+(d[3]<<8),d[4]+(d[5]<<8));
          d[0]=0;
          btc_dptx_aux_write(0,DPCD_ADDR_TEST_SINK,1,d);
        }
      if(cmd[0] == 's')
      {
        // Dump MSA
        bitec_dp_dump_source_msa(btc_dptx_baseaddr(0));
        bitec_dp_dump_source_config(btc_dptx_baseaddr(0));
        bitec_dp_dump_sink_msa(btc_dprx_baseaddr(0));
        bitec_dp_dump_sink_config(btc_dprx_baseaddr(0));
      }
      if(cmd[0] == 'v')
      {
        BYTE maj,min;
        unsigned int ver;
        // Print versions
        btc_dptx_sw_ver(&maj,&min,&ver);
        printf("TX SW library ver. %u.%u.%u\n",maj,min,ver);
        btc_dptx_rtl_ver(&maj,&min,&ver);
        printf("TX RTL core ver. %u.%u.%u\n",maj,min,ver);
#if BITEC_RX_GPUMODE
        btc_dprx_sw_ver(&maj,&min,&ver);
        printf("RX SW library ver. %u.%u.%u\n",maj,min,ver);
        btc_dprx_rtl_ver(&maj,&min,&ver);
        printf("RX RTL core ver. %u.%u.%u\n",maj,min,ver);
#endif
      }
      if((cmd[0] == 'h') && (cmd[1] == 0))
		bitec_menu_print();
    }
#endif
}

