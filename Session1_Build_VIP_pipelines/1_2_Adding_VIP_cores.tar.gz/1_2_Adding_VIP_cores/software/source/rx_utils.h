/*
 * rx_utils.h
 *
 *  Created on: Aug 20, 2020
 *      Author: perezfra
 */

#ifndef _RX_UTILS_H_
#define _RX_UTILS_H_

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

#include "btc_dprx_syslib.h"

void bitec_dprx_isr(void* context);
void bitec_edid_set_stream(BYTE port, BYTE offset, BYTE *edid);

void bitec_mc_monitor(void);
void bitec_mc_lt_handler(BYTE cmd, unsigned int address, BYTE length, BYTE *data);
void bitec_mc_rx_reset(void);
int bitec_mc_cr_check(int lane_cnt);
void bitec_dprx_init(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* _RX_UTILS_H_ */

